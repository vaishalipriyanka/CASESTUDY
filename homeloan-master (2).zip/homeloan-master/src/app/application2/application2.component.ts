import { Component } from '@angular/core';

@Component({
  selector: 'app-application2',
  templateUrl: './application2.component.html',
  styleUrls: ['./application2.component.css']
})
export class Application2Component {

}
