import { Component } from '@angular/core';

@Component({
  selector: 'app-application1',
  templateUrl: './application1.component.html',
  styleUrls: ['./application1.component.css']
})
export class Application1Component {

}
