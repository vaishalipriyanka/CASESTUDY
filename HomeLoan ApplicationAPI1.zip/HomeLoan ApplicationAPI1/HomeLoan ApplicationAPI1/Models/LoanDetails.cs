﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan_ApplicationAPI1.Models
{
    public class LoanDetails
    {
        [Key]
        public int MaxLoanAmt { get; set; }
        public int InterestRate { get; set; }
        public int Tenure { get; set; }
        public int LoanAmount { get; set; }
    }
}
