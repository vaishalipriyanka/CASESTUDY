﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan_ApplicationAPI1.Models
{
    public class UserType
    {
        [Key]
        public string UserTypeId { get; set; }
        public string Type { get; set; }
    }
}
