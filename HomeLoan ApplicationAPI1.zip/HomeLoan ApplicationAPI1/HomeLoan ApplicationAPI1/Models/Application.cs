﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan_ApplicationAPI1.Models
{
    public class Application
    {

        [Key]  public int Id { get; set; }
        public string TypeOfEmployment { get; set; }
        public int IncomeDetails { get; set; }  
        public int RetirementAge { get; set; }
        public string OrganisationType { get; set; }
        public string EmployerName { get; set; }
    }

}
