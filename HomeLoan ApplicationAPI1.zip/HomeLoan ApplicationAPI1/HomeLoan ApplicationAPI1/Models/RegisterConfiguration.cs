﻿//using HomeLoan_ApplicationAPI1.Models;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata.Builders;

//namespace HouseLoanAPI.DataModels
//{
//    public class RegisterConfiguration : IEntityTypeConfiguration<Register>
//    {
//        public void Configure(EntityTypeBuilder<Register> builder)
//        {
//            builder.Property(r => r.Id)
//                .ValueGeneratedOnAdd(); // Ensure the identity column is auto-generated
//        }
//    }
//}
