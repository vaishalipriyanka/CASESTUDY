﻿using HomeLoan_ApplicationAPI1.Models;
using Microsoft.EntityFrameworkCore;

namespace HouseLoanAPI.DataModels
{
    public class UserAdminDbContext : DbContext
    {
        public UserAdminDbContext(DbContextOptions<UserAdminDbContext> options) : base(options)
        {

        }

        public DbSet<UserType> UserType { get; set; }
        public DbSet<Register> Register { get; set; }
        public DbSet<PersonalDetails> PersonalDetails { get; set; }
        public DbSet<LoanDetails> LoanDetails { get; set; }
        public DbSet<LoanTracker> LoanTracker { get; set; }
        public DbSet<IncomeDetails> IncomeDetails { get; set; }
        public DbSet<AccountDetails> AccountDetails { get; set; }
        public DbSet<Application> Application { get; set; }    
        public DbSet<Application1> Application1 { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
          
            modelBuilder.Entity<Register>().ToTable("Register");

            // Other configurations...

            base.OnModelCreating(modelBuilder);
        }
    }
}
