﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan_ApplicationAPI1.Models
{
    public class IncomeDetails
    {
        [Key]
        public int Id { get; set; }
        public string PropertyLocation { get; set; }
        public string PropertyName { get; set; }
        public int EstimatedAmt { get; set; }
        public string TypeOfEmployee { get; set; }
        public int RetirementAge { get; set; }
        public string OrganisationType { get; set; }
       
        public string EmployerName { get; set; }

    }
}
