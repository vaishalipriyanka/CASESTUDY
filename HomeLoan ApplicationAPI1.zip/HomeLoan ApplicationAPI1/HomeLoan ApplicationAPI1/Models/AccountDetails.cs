﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan_ApplicationAPI1.Models
{
    public class AccountDetails
    {
        [Key]
        public string AccountNo { get; set; }
        public int Balance { get; set; }
    }


}