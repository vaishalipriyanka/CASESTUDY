﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan_ApplicationAPI1.Models
{
    public class LoanTracker
    {
        [Key]
        public int ApplicationNo { get; set; }
        public long MobileNo { get; set; }
    }
}
