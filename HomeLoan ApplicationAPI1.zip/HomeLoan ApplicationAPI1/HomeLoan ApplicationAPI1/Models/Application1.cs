﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan_ApplicationAPI1.Models
{
    public class Application1
    {
       [Key] public int ID { get; set; }
        public string Tenure { get; set; }
        public string LoanAmt { get; set; }
    }
}
