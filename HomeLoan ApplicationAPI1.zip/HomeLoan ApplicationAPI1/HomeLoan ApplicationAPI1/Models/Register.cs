﻿using System.ComponentModel.DataAnnotations;

namespace HomeLoan_ApplicationAPI1.Models
{
    public class Register
    {
    
        [Required]
        public string FirstName { get; set; } = string.Empty;
        [Required]
        public string LastName { get; set; } = string.Empty;
        [Key]
        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;
        [Required]
        public string Password { get; set; } = string.Empty;
        [Required]
        public string Phone { get; set; } = string.Empty;
       
    }
}
