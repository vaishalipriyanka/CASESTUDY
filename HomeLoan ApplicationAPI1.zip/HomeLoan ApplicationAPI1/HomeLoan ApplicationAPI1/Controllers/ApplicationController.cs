﻿using HomeLoan_ApplicationAPI1.Models;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using HouseLoanAPI.DataModels;

namespace HomeLoan_ApplicationAPI1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicationController : ControllerBase
    {
        private readonly UserAdminDbContext _context;

        public ApplicationController(UserAdminDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> CreateApplication([FromBody] Application application)
        {
            try
            {
                // Add the application to the context
                _context.Application.Add(application);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Message = "Application created successfully"
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    Message = $"Error creating application: {ex.Message}"
                });
            }
        }
    }
}

