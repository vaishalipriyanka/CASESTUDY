﻿using HomeLoan_ApplicationAPI1.Helpers;
using HomeLoan_ApplicationAPI1.Models;
using HouseLoanAPI.DataModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Threading.Tasks;
using System;
using System.Text;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;


namespace HomeLoan_ApplicationAPI1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterController : ControllerBase
    {
        private readonly UserAdminDbContext _authcontext;

        public RegisterController(UserAdminDbContext userAdminDbContext)
        {
            _authcontext = userAdminDbContext;
        }

        [HttpPost("authenticate")]
        public async Task<IActionResult> Authenticate([FromBody] LoginRequest userObj)
        {
            if (userObj == null)
            {
                return BadRequest();
            }
           ;

            var user = await _authcontext.Register.FirstOrDefaultAsync(x => x.Email == userObj.Email);

            if (user == null)
            {
                return NotFound(new { Message = "User Not Found" });
            }

            bool isPasswordValid = PasswordHasher.VerifyPassword(userObj.Password, user.Password);
            if (!isPasswordValid)
            {
                return BadRequest(new { Message = "Invalid Password" });
            }

            return Ok(new 
            {   
                Message = "Login Success" });
        }

        [HttpPost("register")]
        public async Task<IActionResult> RegisterUser([FromBody] Register registerObj)
        {
            if (registerObj == null)
            {
                return BadRequest();
            }
            if (await CheckEmailExistAsync(registerObj.Email))
                return BadRequest(new { Message = "Email Already Exists" });


            // Exclude the Id property when adding a new Register object
            // Set Id to 0 or omit it completely
            registerObj.Password = PasswordHasher.HashPassword(registerObj.Password);
           
            await _authcontext.Register.AddAsync(registerObj);
            await _authcontext.SaveChangesAsync();

            return Ok(new
            {
                Message = "User Registered"
            });
        }
        private Task<bool> CheckEmailExistAsync(string email)

        => _authcontext.Register.AnyAsync(x => x.Email == email);

        //private string CreateJwt(Register user)
        //{
        //    var jwtTokenHandler = new JwtSecurityTokenHandler();
        //    var key = Encoding.ASCII.GetBytes("veryverysecret.....");
        //    var identity = new ClaimsIdentity(new Claim[]
        //    {
        //        new Claim(ClaimTypes.Role, user.Role),
        //        new Claim(ClaimTypes.Name,$"{user.FirstName}{user.LastName}")
        //    });
        //    var credentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);
        //    var tokenDescriptor = new SecurityTokenDescriptor
        //    {
        //        Subject = identity,
        //        Expires = DateTime.Now.AddDays(1),
        //        SigningCredentials = credentials
        //    };
        //    var token = jwtTokenHandler.CreateToken(tokenDescriptor);
        //    return jwtTokenHandler.WriteToken(token);
        //}

    }
}