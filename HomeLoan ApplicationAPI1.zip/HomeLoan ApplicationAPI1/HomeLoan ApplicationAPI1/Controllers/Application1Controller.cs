﻿using HomeLoan_ApplicationAPI1.Models;
using HouseLoanAPI.DataModels;
using Microsoft.AspNetCore.Mvc;

namespace HomeLoan_ApplicationAPI1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class Application1Controller : ControllerBase
    {
        private readonly UserAdminDbContext _context;

        public Application1Controller(UserAdminDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult CreateApplication1([FromBody] Application1 application1)
        {
            try
            {
                
                _context.Application1.Add(application1);
                _context.SaveChanges();

                return Ok(new
                {
                    Message = "Application created successfully",
                    ID = application1.ID
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    Message = $"Error creating application: {ex.Message}"
                });
            }
        }
    }
}
