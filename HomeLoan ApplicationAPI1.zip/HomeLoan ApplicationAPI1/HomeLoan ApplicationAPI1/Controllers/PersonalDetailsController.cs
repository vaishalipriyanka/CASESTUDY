﻿using System;
using Microsoft.AspNetCore.Mvc;
using HomeLoan_ApplicationAPI1.Models;
using HouseLoanAPI.DataModels;

namespace HomeLoan_ApplicationAPI1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonalDetailsController : ControllerBase
    {
        private readonly UserAdminDbContext _context;

        public PersonalDetailsController(UserAdminDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public ActionResult<PersonalDetails> AddPersonalDetails(PersonalDetails personalDetails)
        {
            try
            {

                _context.PersonalDetails.Add(personalDetails);
                _context.SaveChanges();

                    return Ok(new
                {
                    Message = "Received Personal Details successfully"
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
