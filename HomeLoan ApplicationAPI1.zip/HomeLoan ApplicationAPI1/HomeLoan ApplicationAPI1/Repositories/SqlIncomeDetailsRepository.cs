﻿using HomeLoan_ApplicationAPI1.Models;
using HouseLoanAPI.DataModels;

namespace HomeLoan_ApplicationAPI1.Repositories
{
    public class SqlIncomeDetailsRepository: IIncomeDetailsRepository
    { 
        private readonly UserAdminDbContext context;

        public SqlIncomeDetailsRepository(UserAdminDbContext context)
        {
            this.context = context;
        }
        public List<IncomeDetails> GetIncomeDetails()
        {
            return context.IncomeDetails.ToList();
        }
    }
}
