﻿using HomeLoan_ApplicationAPI1.Models;
using HouseLoanAPI.DataModels;

namespace HomeLoan_ApplicationAPI1.Repositories
{
    public class SqlAccountDetailsRepository: IAccountDetailsRepository
    {
        private readonly UserAdminDbContext context;

        public SqlAccountDetailsRepository(UserAdminDbContext context)
        {
            this.context = context;
        }
        public List<AccountDetails> GetAccountDetails()
        {
            return context.AccountDetails.ToList();
        }
        public void Add (AccountDetails accd) { context.AccountDetails.Add(accd);
            context.SaveChanges();
        }
    }
}
