﻿using HomeLoan_ApplicationAPI1.Models;
using HouseLoanAPI.DataModels;

namespace HomeLoan_ApplicationAPI1.Repositories
{
    public class SqlLoanDetailsRepository: ILoanDetailsRepository
    {
        private readonly UserAdminDbContext context;

        public SqlLoanDetailsRepository(UserAdminDbContext context)
        {
            this.context = context;
        }
        public List<LoanDetails> GetLoanDetails()
        {
            return context.LoanDetails.ToList();
        }
    }
}
