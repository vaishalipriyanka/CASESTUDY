﻿using HomeLoan_ApplicationAPI1.Models;
using HouseLoanAPI.DataModels;

namespace HomeLoan_ApplicationAPI1.Repositories
{
    public class SqlLoanTrackerRepository: ILoanTrackerRepository
    {
        private readonly UserAdminDbContext context;

        public SqlLoanTrackerRepository(UserAdminDbContext context)
        {
            this.context = context;
        }
        public List<LoanTracker> GetLoanTrackerDetails()
        {
            return context.LoanTracker.ToList();
        }
    }
}
