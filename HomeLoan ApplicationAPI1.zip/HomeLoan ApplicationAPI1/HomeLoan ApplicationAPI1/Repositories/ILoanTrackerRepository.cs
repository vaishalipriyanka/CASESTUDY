﻿using HomeLoan_ApplicationAPI1.Models;

namespace HomeLoan_ApplicationAPI1.Repositories
{
    public interface ILoanTrackerRepository
    {
        List<LoanTracker> GetLoanTrackerDetails();
    }
}
